﻿using System;

namespace SantasCookies
{
    class Program
    {
        static void Main(string[] args)
        {
            int numberOfBatches = int.Parse(Console.ReadLine());

            int totalBoxes = 0;

            for (int i = 0; i < numberOfBatches; i++)
            {
                int flour = int.Parse(Console.ReadLine());
                int sugar = int.Parse(Console.ReadLine());
                int cacao = int.Parse(Console.ReadLine());

                double flourCups = flour / 140;
                double sugarSpoons = sugar / 20;
                double cacaoSpoons = cacao / 10;

                if (flourCups <= 0 || sugarSpoons <= 0 || cacaoSpoons <= 0)
                {
                    Console.WriteLine("Ingredients are not enough for a box of cookies.");
                    continue;
                }

                double cookiesPerBake = Math.Floor((170 * Math.Min(flourCups, Math.Min(sugarSpoons, cacaoSpoons))) / 25);

                int boxesPerBatch = (int)cookiesPerBake / 5;

                Console.WriteLine($"Boxes of cookies: {boxesPerBatch}");
                totalBoxes += boxesPerBatch;
            }

            Console.WriteLine($"Total boxes: {totalBoxes}");
        }
    }
}
