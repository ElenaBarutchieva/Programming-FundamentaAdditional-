﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SantasGifts
{
    class Program
    {
        static void Main(string[] args)
        {
            int numberOfCommands = int.Parse(Console.ReadLine());

            int santasIndex = 0;

            List<string> houses = Console.ReadLine()
                .Split()
                .ToList();

            for (int i = 0; i < numberOfCommands; i++)
            {
                string[] command = Console.ReadLine().Split();

                switch (command[0])
                {
                    case "Forward":
                        if ((santasIndex + int.Parse(command[1])) >= houses.Count)
                        {
                            continue;
                        }
                        santasIndex += int.Parse(command[1]);
                        houses.RemoveAt(santasIndex);
                        break;
                    case "Back":
                        if ((santasIndex - int.Parse(command[1])) < 0)
                        {
                            continue;
                        }
                        santasIndex -= int.Parse(command[1]);
                        houses.RemoveAt(santasIndex);
                        break;
                    case "Swap":
                        string firstHouse = command[1];
                        string secondHouse = command[2];

                        int firstIndex = houses.IndexOf(firstHouse);
                        int secondIndex = houses.IndexOf(secondHouse);

                        if (firstIndex < 0 || secondIndex < 0)
                        {
                            continue;
                        }
                        houses[firstIndex] = secondHouse;
                        houses[secondIndex] = firstHouse;
                        break;
                    case "Gift":
                        if (int.Parse(command[1]) < 0 || int.Parse(command[1]) >= houses.Count)
                        {
                            continue;
                        }
                        houses.Insert(int.Parse(command[1]), command[2]);
                        santasIndex = int.Parse(command[1]);
                        break;
                }

            }
            Console.WriteLine($"Position: {santasIndex}");
            Console.WriteLine(string.Join(", ", houses));
        }
    }
}
