﻿using System;
using System.Text.RegularExpressions;

namespace SantansSecretHelper
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = int.Parse(Console.ReadLine());

            string input = Console.ReadLine();

            string pattern = @"@([a-zA-Z]+)[^@\-!:>]+!([G,N])!";

            while (input != "end")
            {
                var massage = "";
                foreach (var letter in input)
                {
                    int newSymbol = (int)letter - number;
                    massage += (char)newSymbol;
                }

                Regex regex = new Regex(pattern);

                Match match = regex.Match(massage);

                if (match.Success)
                {
                    var matches = match.Groups;
                    string name = matches[1].Value;
                    string behavior = matches[2].Value;

                    if (behavior == "G")
                    {
                        Console.WriteLine(name);
                    }
                }

                input = Console.ReadLine();
            }
        }
    }
}