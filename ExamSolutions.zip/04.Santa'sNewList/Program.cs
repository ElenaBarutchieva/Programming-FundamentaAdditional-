﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SantasNewList
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();

            var children = new Dictionary<string, int>();
            var presents = new Dictionary<string, int>();

            while (input != "END")
            {
                string[] commannd = input.Split("->");

                if (commannd.Length == 3)
                {
                    string name = commannd[0];
                    string present = commannd[1];
                    int amount = int.Parse(commannd[2]);

                    if (!children.ContainsKey(name))
                    {
                        children[name] = 0;
                    }
                    children[name] += amount;

                    if (!presents.ContainsKey(present))
                    {
                        presents[present] = 0;
                    }
                    presents[present] += amount;
                }
                else
                {
                    if (children.ContainsKey(commannd[1]))
                    {
                        children.Remove(commannd[1]);
                    }
                }

                input = Console.ReadLine();
            }

            Console.WriteLine("Children:");
            foreach (var child in children.OrderByDescending(x => x.Value).ThenBy(y => y.Key))
            {
                Console.WriteLine($"{child.Key} -> {child.Value}");
            }
            Console.WriteLine("Presents:");
            foreach (var present in presents)
            {
                Console.WriteLine($"{present.Key} -> {present.Value}");
            }
        }
    }
}